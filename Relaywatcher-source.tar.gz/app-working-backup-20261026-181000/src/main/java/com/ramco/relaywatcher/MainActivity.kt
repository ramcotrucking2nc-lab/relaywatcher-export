package com.ramco.relaywatcher

import android.os.Bundle
import android.widget.TextView
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.google.android.material.switchmaterial.SwitchMaterial

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main)) { v, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(
                systemBars.left + 24,
                systemBars.top + 24,
                systemBars.right + 24,
                systemBars.bottom + 24
            )
            insets
        }

        val prefs = getSharedPreferences("relaywatcher", MODE_PRIVATE)
        val autoSwitch = findViewById<SwitchMaterial>(R.id.autoBookerSwitch)
        val status = findViewById<TextView>(R.id.statusText)

        val enabled = prefs.getBoolean("auto_booker_enabled", false)
        autoSwitch.isChecked = enabled
        status.text = if (enabled) "Auto Booker: ON" else "Auto Booker: OFF"

        autoSwitch.setOnCheckedChangeListener { _, isChecked ->
            prefs.edit()
                .putBoolean("auto_booker_enabled", isChecked)
                .apply()

            status.text =
                if (isChecked) "Auto Booker: ON"
                else "Auto Booker: OFF"
        }
    }
}
