package com.ramco.relaywatcher

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RelayAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    private val pollRunnable = object : Runnable {
        override fun run() {
            scanCurrentScreen()
            handler.postDelayed(this, 75)
        }
    }

    private val refreshRunnable = object : Runnable {
        override fun run() {
            autoBookerEnabled =
                getSharedPreferences("relaywatcher", MODE_PRIVATE)
                    .getBoolean("auto_booker_enabled", false)

            if (autoBookerEnabled) {
                val refreshClicked = clickRefresh()

                refreshCount++
                if (refreshClicked) {
                    refreshSuccessCount++
                }

                val now = android.os.SystemClock.elapsedRealtime()

                if (now - refreshWindowStart >= 1000) {
                    Log.d(
                        TAG,
                        "REFRESHES/SEC: attempts=$refreshCount successful=$refreshSuccessCount"
                    )
                    refreshCount = 0
                    refreshSuccessCount = 0
                    refreshWindowStart = now
                }
            }

            handler.postDelayed(this, 250)
        }
    }

    companion object {
        const val TAG = "RelayWatcher"
    }

    private var lastSnapshot = ""
    private var lastHeartbeat = 0L
    private var lastStatusLog = 0L
    private var scanCount = 0
    private var scanWindowStart = android.os.SystemClock.elapsedRealtime()

    private var scanTimeTotalUs = 0L
    private var scanTimeSamples = 0
    private var scanTimeMaxUs = 0L

    private var refreshCount = 0
    private var refreshSuccessCount = 0
    private var refreshWindowStart = android.os.SystemClock.elapsedRealtime()
    private var testCardClicked = false
    private var waitingForBook = false
    private var bookClicked = false
    private var waitingForConfirm = false
    private var confirmClicked = false
    private var waitingForLoadBoard = false
    private var loadBoardClicked = false
    private var autoBookerEnabled = false
    private var attemptActive = false
    private var lastAttemptKey = ""
    private var retryBlockUntil = 0L
    private var resumeSearchAt = 0L

    private val allowedLanes = setOf(
        "BNSF-CICERO" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "BNSF-CICERO",

        "BNSF-CORWITH" to "BNSF-CICERO",
        "BNSF-CICERO" to "BNSF-CORWITH",

        "CSXT-BEDFORD PARK" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "CSXT-BEDFORD PARK",

        "BNSF-WILLOW SPRINGS" to "BNSF-CICERO",
        "BNSF-CICERO" to "BNSF-WILLOW SPRINGS",

        "BNSF-WILLOW SPRINGS" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "BNSF-WILLOW SPRINGS",

        "BNSF-WILLOW SPRINGS" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "BNSF-WILLOW SPRINGS",

        "NSRR-LANDERS" to "BNSF-CICERO",
        "BNSF-CICERO" to "NSRR-LANDERS",

        "NSRR-LANDERS" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "NSRR-LANDERS",

        "NSRR-LANDERS" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "NSRR-LANDERS",

        "NSRR-CHICAGO-47TH" to "BNSF-CICERO",
        "BNSF-CICERO" to "NSRR-CHICAGO-47TH",

        "NSRR-CHICAGO-47TH" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "NSRR-CHICAGO-47TH",

        "NSRR-CHICAGO-47TH" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "NSRR-CHICAGO-47TH"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "RelayWatcher connected")
        handler.removeCallbacks(pollRunnable)
        handler.removeCallbacks(refreshRunnable)

        handler.post(pollRunnable)
        handler.post(refreshRunnable)
    }

    override fun onInterrupt() {}

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                logVisibleRelayText()
                scanCurrentScreen()
            }
        }
    }

    private fun recordScanTime(startNs: Long) {
        val elapsedUs =
            (android.os.SystemClock.elapsedRealtimeNanos() - startNs) / 1000

        scanTimeTotalUs += elapsedUs
        scanTimeSamples++

        if (elapsedUs > scanTimeMaxUs) {
            scanTimeMaxUs = elapsedUs
        }

        if (scanTimeSamples >= 10) {
            val avgUs = scanTimeTotalUs / scanTimeSamples

            Log.d(
                TAG,
                "SCAN TIME: avg=${avgUs / 1000.0}ms max=${scanTimeMaxUs / 1000.0}ms samples=$scanTimeSamples"
            )

            scanTimeTotalUs = 0
            scanTimeSamples = 0
            scanTimeMaxUs = 0
        }
    }

    private var lastTextDumpAt = 0L

    private fun logVisibleRelayText() {
        val now = android.os.SystemClock.elapsedRealtime()

        // Throttle to at most 5 dumps/sec
        if (now - lastTextDumpAt < 200L) return
        lastTextDumpAt = now

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()

        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return

            node.text?.toString()?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.let { texts.add(it) }

            node.contentDescription?.toString()?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.let { texts.add(it) }

            for (i in 0 until node.childCount) {
                walk(node.getChild(i))
            }
        }

        walk(root)

        if (texts.isNotEmpty()) {
            Log.e(TAG, "UI-TEXT: " + texts.joinToString(" | "))
        }
    }

    private fun scanCurrentScreen() {
        autoBookerEnabled =
            getSharedPreferences("relaywatcher", MODE_PRIVATE)
                .getBoolean("auto_booker_enabled", false)

        scanCount++

        val scanNow = android.os.SystemClock.elapsedRealtime()
        if (scanNow - scanWindowStart >= 1000) {
            Log.d(TAG, "SCANS/SEC: $scanCount")
            scanCount = 0
            scanWindowStart = scanNow
        }
        val startNs = android.os.SystemClock.elapsedRealtimeNanos()

        val now = android.os.SystemClock.elapsedRealtime()
        if (now - lastHeartbeat >= 1000) {
            lastHeartbeat = now
            Log.d(TAG, "SCAN-ALIVE")
        }



        val root = rootInActiveWindow
        if (root == null) {
            recordScanTime(startNs)
            return
        }

        findLoadCards(root)
        findBookButton(root)
        findConfirmAndBookButton(root)
        findBackToLoadBoardButton(root)
        val texts = mutableListOf<String>()
        collectText(root, texts)

        val rails = texts
            .filter { isRailLocation(it) }
            .map { normalizeRail(it) }

        val distanceRegex =
            Regex("""^\s*(\d+)\s*miles?\s*$""", RegexOption.IGNORE_CASE)

        val miles = texts.mapNotNull { text ->
            distanceRegex.matchEntire(text)
                ?.groupValues
                ?.get(1)
                ?.toIntOrNull()
        }


        val statusNow = android.os.SystemClock.elapsedRealtime()
        if (statusNow - lastStatusLog >= 1000) {
            lastStatusLog = statusNow
            Log.d(TAG, "STATUS: rails=${rails.size} miles=${miles.size}")

        if (rails.size % 2 != 0) {
            Log.d(TAG, "ODD-RAILS: ${rails.joinToString(" || ")}")

            for (t in texts) {
                if (
                    t.contains(", IL", ignoreCase = true) ||
                    t.contains("CHICAGO", ignoreCase = true) ||
                    t.contains("BEDFORD", ignoreCase = true) ||
                    t.contains("CICERO", ignoreCase = true) ||
                    t.contains("CORWITH", ignoreCase = true) ||
                    t.contains("LANDERS", ignoreCase = true)
                ) {
                    Log.d(TAG, "LOCATION-TEXT: $t")
                }
            }
        }
        }

        val snapshot = rails.joinToString("|") + "::" + miles.joinToString(",")

        if (snapshot == lastSnapshot) {
            recordScanTime(startNs)
            return
        }
        lastSnapshot = snapshot


        val loadCount = minOf(rails.size / 2, miles.size)

        for (i in 0 until loadCount) {
            val origin = rails[i * 2]
            val destination = rails[i * 2 + 1]
            val loadedMiles = miles[i]

            val laneAllowed = allowedLanes.contains(origin to destination)
            val milesAllowed = loadedMiles <= 12
            val finalMatch = laneAllowed && milesAllowed

            val endNs = android.os.SystemClock.elapsedRealtimeNanos()
            val processingUs = (endNs - startNs) / 1000

            Log.d(
                TAG,
                "SPEED: ${processingUs}us | $origin -> $destination | ${loadedMiles}mi"
            )


            Log.d(
                TAG,
                "TEST: $origin -> $destination | ${loadedMiles}mi | " +
                    "LANE=${if (laneAllowed) "YES" else "NO"} | " +
                    "DIST=${if (milesAllowed) "YES" else "NO"}"
            )

            if (finalMatch) {
                Log.e(
                    TAG,
                    "!!! MATCH DETECTED !!! $origin -> $destination | ${loadedMiles}mi"
                )
            }
        }

        recordScanTime(startNs)
    }


    private fun clickRefresh(): Boolean {
        val root = rootInActiveWindow ?: return false

        fun search(node: AccessibilityNodeInfo?): Boolean {
            if (node == null) return false

            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""

            val isRefresh =
                text.equals("Refresh", ignoreCase = true) ||
                desc.contains("Refresh", ignoreCase = true)

            if (isRefresh) {
                if (node.isClickable) {
                    if (node.performAction(
                            AccessibilityNodeInfo.ACTION_CLICK
                        )
                    ) return true
                }

                val parent = node.parent

                if (parent != null) {
                    if (parent.isClickable) {
                        if (parent.performAction(
                                AccessibilityNodeInfo.ACTION_CLICK
                            )
                        ) return true
                    }

                    for (i in 0 until parent.childCount) {
                        val sibling = parent.getChild(i) ?: continue

                        if (sibling.isClickable) {
                            if (sibling.performAction(
                                    AccessibilityNodeInfo.ACTION_CLICK
                                )
                            ) return true
                        }
                    }
                }
            }

            for (i in 0 until node.childCount) {
                if (search(node.getChild(i))) return true
            }

            return false
        }

        return search(root)
    }


    private fun findLoadCards(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false

        // Search smaller child subtrees FIRST.
        // This prevents the entire Relay screen from being mistaken for one load card.
        for (i in 0 until node.childCount) {
            if (findLoadCards(node.getChild(i))) {
                return true
            }
        }

        val allTexts = mutableListOf<String>()
        collectText(node, allTexts)

        val distanceRegex =
            Regex("""^\s*(\d+)\s*miles?\s*$""", RegexOption.IGNORE_CASE)

        val distances = allTexts.filter {
            distanceRegex.matches(it)
        }

        val locations = allTexts.filter {
            val t = it.uppercase()

            !t.contains("UIIA") && (
                t.contains("BNSF") ||
                t.contains("CSXT") ||
                t.contains("NSRR") ||
                t.contains("UPRR")
            )
        }

        if (distances.size == 1 && locations.size == 2) {
            val origin = normalizeRail(locations[0])
            val destination = normalizeRail(locations[1])

            val miles = Regex("\\d+")
                .find(distances[0])
                ?.value
                ?.toIntOrNull()
                ?: return false

            val laneAllowed =
                allowedLanes.contains(origin to destination)

            // TEMP TEST: prove the fast per-card match path works.
            val bounds = android.graphics.Rect()
            node.getBoundsInScreen(bounds)

            var clickableNode: AccessibilityNodeInfo? = node
            var levelsUp = 0

            while (clickableNode != null &&
                   !clickableNode.isClickable &&
                   levelsUp < 6) {
                clickableNode = clickableNode.parent
                levelsUp++
            }

            val clickBounds = android.graphics.Rect()
            clickableNode?.getBoundsInScreen(clickBounds)

            Log.e(
                TAG,
                "!!! TEST MATCH !!! $origin -> $destination | ${miles}mi | REAL=${laneAllowed && miles <= 12} | CARD=$bounds | CLICKABLE=${clickableNode?.isClickable} | UP=$levelsUp | CLICK_BOUNDS=$clickBounds"
            )

            val attemptKey =
                "$origin|$destination|$miles|" +
                "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"

            val now = android.os.SystemClock.elapsedRealtime()

            if (loadBoardClicked && now >= resumeSearchAt) {
                loadBoardClicked = false
            }

            val recentlyAttemptedSameCard =
                attemptKey == lastAttemptKey &&
                now < retryBlockUntil

            if (
                autoBookerEnabled &&
                laneAllowed &&
                miles <= 12 &&
                !attemptActive &&
                !recentlyAttemptedSameCard &&
                !testCardClicked &&
                clickableNode?.isClickable == true
            ) {
                val clicked = clickableNode!!.performAction(
                    AccessibilityNodeInfo.ACTION_CLICK
                )

                Log.e(
                    TAG,
                    "REAL CARD CLICK: success=$clicked | $origin -> $destination | ${miles}mi"
                )

                if (clicked) {
                    testCardClicked = true
                    attemptActive = true
                    lastAttemptKey = attemptKey

                    // Don't immediately hit this exact same card again
                    // after returning to the board.
                    retryBlockUntil =
                        android.os.SystemClock.elapsedRealtime() + 5000L

                    waitingForBook = true

                    // First qualifying load clicked.
                    // Stop scanning all remaining load cards immediately.
                    return true
                }
            }

            if (laneAllowed && miles <= 12) {
                Log.e(
                    TAG,
                    "!!! MATCH DETECTED !!! $origin -> $destination | ${miles}mi"
                )
            }

            // This subtree is already one complete load card.
            // Do not descend farther and detect the same card again.
            return false
        }

        return false
    }


    private fun findBookButton(node: AccessibilityNodeInfo?) {
        if (node == null) return

        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""

        val isBook =
            text.equals("Book", ignoreCase = true) ||
            desc.equals("Book", ignoreCase = true)

        if (isBook) {
            val bounds = android.graphics.Rect()
            node.getBoundsInScreen(bounds)

            var clickableNode: AccessibilityNodeInfo? = node
            var levelsUp = 0

            while (clickableNode != null &&
                   !clickableNode.isClickable &&
                   levelsUp < 6) {
                clickableNode = clickableNode.parent
                levelsUp++
            }

            val clickBounds = android.graphics.Rect()
            clickableNode?.getBoundsInScreen(clickBounds)

            Log.e(
                TAG,
                "BOOK BUTTON FOUND | textBounds=$bounds | CLICKABLE=${clickableNode?.isClickable} | UP=$levelsUp | CLICK_BOUNDS=$clickBounds | class=${clickableNode?.className}"
            )

            if (
                autoBookerEnabled &&
                attemptActive &&
                waitingForBook &&
                !bookClicked &&
                clickableNode?.isClickable == true
            ) {
                val clicked = clickableNode.performAction(
                    AccessibilityNodeInfo.ACTION_CLICK
                )

                Log.e(TAG, "BOOK CLICK: success=$clicked")

                if (clicked) {
                    bookClicked = true
                    waitingForBook = false
                    waitingForConfirm = true
                }
            }
        }

        for (i in 0 until node.childCount) {
            findBookButton(node.getChild(i))
        }
    }


    private fun findConfirmAndBookButton(node: AccessibilityNodeInfo?) {
        if (node == null) return

        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""

        val isConfirmAndBook =
            text.equals("Confirm and book", ignoreCase = true) ||
            desc.equals("Confirm and book", ignoreCase = true)

        if (isConfirmAndBook) {
            val textBounds = android.graphics.Rect()
            node.getBoundsInScreen(textBounds)

            var clickableNode: AccessibilityNodeInfo? = node
            var levelsUp = 0

            while (
                clickableNode != null &&
                !clickableNode.isClickable &&
                levelsUp < 6
            ) {
                clickableNode = clickableNode.parent
                levelsUp++
            }

            val clickBounds = android.graphics.Rect()
            clickableNode?.getBoundsInScreen(clickBounds)

            Log.e(
                TAG,
                "CONFIRM BUTTON FOUND | textBounds=$textBounds | CLICKABLE=${clickableNode?.isClickable} | UP=$levelsUp | CLICK_BOUNDS=$clickBounds | class=${clickableNode?.className}"
            )

            if (
                autoBookerEnabled &&
                attemptActive &&
                waitingForConfirm &&
                !confirmClicked &&
                clickableNode?.isClickable == true
            ) {
                val clicked = clickableNode.performAction(
                    AccessibilityNodeInfo.ACTION_CLICK
                )

                Log.e(TAG, "CONFIRM CLICK: success=$clicked")

                if (clicked) {
                    confirmClicked = true
                    waitingForConfirm = false
                    waitingForLoadBoard = true
                }
            }
        }

        for (i in 0 until node.childCount) {
            findConfirmAndBookButton(node.getChild(i))
        }
    }


    private fun findBackToLoadBoardButton(node: AccessibilityNodeInfo?) {
        if (node == null) return

        val text = node.text?.toString()?.trim() ?: ""
        val desc = node.contentDescription?.toString()?.trim() ?: ""

        val isBackToLoadBoard =
            text.equals("Back to Load Board", ignoreCase = true) ||
            desc.equals("Back to Load Board", ignoreCase = true)

        if (isBackToLoadBoard) {
            Log.e(TAG, "BACK TO LOAD BOARD FOUND")

            var clickableNode: AccessibilityNodeInfo? = node
            var levelsUp = 0

            while (
                clickableNode != null &&
                !clickableNode.isClickable &&
                levelsUp < 6
            ) {
                clickableNode = clickableNode.parent
                levelsUp++
            }

            if (
                attemptActive &&
                !loadBoardClicked &&
                clickableNode?.isClickable == true
            ) {
                loadBoardClicked = true
                waitingForLoadBoard = false

                val clicked = clickableNode.performAction(
                    AccessibilityNodeInfo.ACTION_CLICK
                )

                Log.e(TAG, "BACK TO LOAD BOARD CLICK: success=$clicked")

                if (clicked) {
                    attemptActive = false

                    waitingForBook = false
                    waitingForConfirm = false
                    waitingForLoadBoard = false

                    testCardClicked = false
                    bookClicked = false
                    confirmClicked = false

                    // Give Relay time to return to the board.
                    // Refresh/search resumes automatically afterward.
                    resumeSearchAt =
                        android.os.SystemClock.elapsedRealtime() + 750L

                    Log.e(TAG, "ATTEMPT FINISHED - RESUMING LOAD BOARD")
                }
            }
        }

        for (i in 0 until node.childCount) {
            findBackToLoadBoardButton(node.getChild(i))
        }
    }

    private fun collectText(
        node: AccessibilityNodeInfo?,
        output: MutableList<String>
    ) {
        if (node == null) return

        val text = node.text?.toString()?.trim()

        if (!text.isNullOrBlank()) {
            output.add(text)
        }

        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), output)
        }
    }

    private fun isRailLocation(text: String): Boolean {
        val t = text.uppercase()

        if (t.contains("UIIA")) return false

        return (
            t.contains("BNSF") && (
                t.contains("CICERO") ||
                t.contains("CORWITH") ||
                t.contains("WILLOW")
            )
        ) || (
            t.contains("CSXT") &&
            t.contains("BEDFORD")
        ) || (
            t.contains("NSRR") && (
                t.contains("LANDERS") ||
                t.contains("47TH") ||
                t.contains("63RD") ||
                t.contains("CALUMET")
            )
        ) || (
            t.contains("UPRR") && (
                t.contains("DOLTON") ||
                t.contains("GLOBAL")
            )
        ) || t.contains("IGQ1")
    }

    private fun normalizeRail(raw: String): String {
        var t = raw.uppercase()

        t = t
            .replace("-CS", "")
            .replace("-TOT", "")
            .replace("-EFC", "")

        return when {
            t.contains("BNSF") && t.contains("CICERO") ->
                "BNSF-CICERO"

            t.contains("BNSF") && t.contains("CORWITH") ->
                "BNSF-CORWITH"

            t.contains("BNSF") && t.contains("WILLOW") ->
                "BNSF-WILLOW SPRINGS"

            t.contains("CSXT") && t.contains("BEDFORD") ->
                "CSXT-BEDFORD PARK"

            t.contains("NSRR") && t.contains("LANDERS") ->
                "NSRR-LANDERS"

            t.contains("NSRR") && t.contains("47TH") ->
                "NSRR-CHICAGO-47TH"

            t.contains("IGQ1") ->
                "IGQ1-HARVEY"

            else -> t.trim()
        }
    }
}
