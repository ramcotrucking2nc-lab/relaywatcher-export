package com.ramco.relaywatcher

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

object TelemetryUploader {

    private const val TAG = "RelayTelemetry"

    private const val ENDPOINT =
        "https://djfydnjmhinijgbwzypw.supabase.co/functions/v1/relay-ingest-6c29293a546a97e3e0bdbc3e"

    /*
     * ONE completely separate worker thread.
     *
     * Booking/accessibility code only calls executor.execute().
     * ALL networking happens on this background thread.
     */
    private val executor =
        Executors.newSingleThreadExecutor { runnable ->
            Thread(runnable, "RelayTelemetryWorker").apply {
                priority = Thread.MIN_PRIORITY
            }
        }

    fun sendAttempt(
        context: Context,
        success: Boolean,
        reason: String,
        origin: String,
        destination: String,
        miles: Int,
        cardToBookMs: Long?,
        bookToConfirmMs: Long?,
        totalMs: Long
    ) {
        val appContext = context.applicationContext

        executor.execute {
            try {
                val body = JSONObject().apply {
                    put("device_id", android.os.Build.MODEL ?: "Android")
                    put(
                        "event_type",
                        if (success)
                            "booking_success"
                        else
                            "booking_failed"
                    )

                    put("origin", origin)
                    put("destination", destination)
                    put("miles", miles)

                    if (cardToBookMs != null) {
                        put("card_to_book_ms", cardToBookMs)
                    }

                    if (bookToConfirmMs != null) {
                        put("book_to_confirm_ms", bookToConfirmMs)
                    }

                    put("total_ms", totalMs)
                    put("success", success)

                    if (!success) {
                        put("failure_reason", reason)
                    }

                    put(
                        "uptime_ms",
                        android.os.SystemClock.elapsedRealtime()
                    )

                    put(
                        "meta",
                        JSONObject().apply {
                            put("reason", reason)
                            put(
                                "app",
                                appContext.packageName
                            )
                        }
                    )
                }

                postJson(body)

            } catch (t: Throwable) {
                /*
                 * Telemetry failure must NEVER affect booking.
                 */
                Log.w(
                    TAG,
                    "Telemetry dropped: ${t.message}"
                )
            }
        }
    }

    fun sendHeartbeat(
        context: Context
    ) {
        executor.execute {
            try {
                val body = JSONObject().apply {
                    put(
                        "device_id",
                        android.os.Build.MODEL ?: "Android"
                    )

                    put("event_type", "heartbeat")

                    put(
                        "uptime_ms",
                        android.os.SystemClock.elapsedRealtime()
                    )

                    put(
                        "meta",
                        JSONObject().apply {
                            put(
                                "app",
                                context.applicationContext.packageName
                            )
                        }
                    )
                }

                postJson(body)

            } catch (t: Throwable) {
                Log.w(
                    TAG,
                    "Heartbeat dropped: ${t.message}"
                )
            }
        }
    }

    private fun postJson(
        body: JSONObject
    ) {
        var connection: HttpURLConnection? = null

        try {
            connection =
                URL(ENDPOINT)
                    .openConnection() as HttpURLConnection

            connection.requestMethod = "POST"
            connection.connectTimeout = 3000
            connection.readTimeout = 3000
            connection.doOutput = true

            connection.setRequestProperty(
                "Content-Type",
                "application/json"
            )

            connection.outputStream.use {
                it.write(
                    body.toString()
                        .toByteArray(Charsets.UTF_8)
                )
            }

            val code = connection.responseCode

            Log.d(
                TAG,
                "Telemetry response=$code"
            )

        } catch (t: Throwable) {
            /*
             * Network problems stay isolated here.
             */
            Log.w(
                TAG,
                "Upload failed: ${t.message}"
            )

        } finally {
            connection?.disconnect()
        }
    }
}
