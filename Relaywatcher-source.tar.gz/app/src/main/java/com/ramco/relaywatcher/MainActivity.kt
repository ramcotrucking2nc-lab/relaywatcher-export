package com.ramco.relaywatcher

import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.Button
import android.widget.Spinner
import android.widget.ArrayAdapter
import android.widget.AdapterView
import android.view.View
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private val prefs by lazy {
        getSharedPreferences("relaywatcher", MODE_PRIVATE)
    }

    private lateinit var autoBookerSwitch: Switch
    private lateinit var refreshSeekBar: SeekBar
    private lateinit var refreshRateValue: TextView
    private lateinit var stemSpinner: Spinner
    private lateinit var stemValueText: TextView

    private lateinit var statusCard: LinearLayout
    private lateinit var statusText: TextView
    private lateinit var statusSubtext: TextView

    private lateinit var successCountText: TextView
    private lateinit var failCountText: TextView
    private lateinit var avgTimeText: TextView

    private lateinit var successHistoryText: TextView
    private lateinit var failHistoryText: TextView

    private val handler = Handler(Looper.getMainLooper())

    private val statsRunnable = object : Runnable {
        override fun run() {
            refreshDashboard()
            handler.postDelayed(this, 1000L)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        autoBookerSwitch = findViewById(R.id.autoBookerSwitch)
        refreshSeekBar = findViewById(R.id.refreshSeekBar)
        refreshRateValue = findViewById(R.id.refreshRateValue)
        stemSpinner = findViewById(R.id.stemSpinner)
        stemValueText = findViewById(R.id.stemValueText)

        statusCard = findViewById(R.id.statusCard)
        statusText = findViewById(R.id.statusText)
        statusSubtext = findViewById(R.id.statusSubtext)

        successCountText = findViewById(R.id.successCountText)
        failCountText = findViewById(R.id.failCountText)
        avgTimeText = findViewById(R.id.avgTimeText)

        successHistoryText = findViewById(R.id.successHistoryText)
        failHistoryText = findViewById(R.id.failHistoryText)

        val stopButton =
            findViewById<Button>(R.id.stopButton)

        val clearHistoryButton =
            findViewById<Button>(R.id.clearHistoryButton)

        // Preserve existing Auto Booker preference.
        val autoEnabled =
            prefs.getBoolean(
                "auto_booker_enabled",
                false
            )

        autoBookerSwitch.isChecked =
            autoEnabled

        // Preserve existing refresh-rate preference.
        val savedRefreshRate =
            prefs.getInt(
                "refresh_rate",
                1
            ).coerceIn(1, 10)

        refreshSeekBar.progress =
            savedRefreshRate - 1

        updateRefreshLabel(savedRefreshRate)


        // Minimum stem-time filter.
        val stemLabels =
            listOf(
                "1 hour",
                "1.5 hours",
                "2 hours",
                "3 hours",
                "4 hours",
                "6 hours",
                "8 hours"
            )

        val stemValues =
            listOf(
                60,
                90,
                120,
                180,
                240,
                360,
                480
            )

        val savedStem =
            prefs.getInt(
                "minimum_stem_minutes",
                90
            )

        val stemAdapter =
            ArrayAdapter(
                this,
                android.R.layout.simple_spinner_item,
                stemLabels
            )

        stemAdapter.setDropDownViewResource(
            android.R.layout.simple_spinner_dropdown_item
        )

        stemSpinner.adapter =
            stemAdapter

        val savedStemIndex =
            stemValues.indexOf(savedStem)
                .let {
                    if (it >= 0) it else 1
                }

        stemSpinner.setSelection(
            savedStemIndex
        )

        stemValueText.text =
            "Minimum: ${stemLabels[savedStemIndex]} before pickup"

        stemSpinner.onItemSelectedListener =
            object :
                AdapterView.OnItemSelectedListener {

                override fun onItemSelected(
                    parent: AdapterView<*>?,
                    view: View?,
                    position: Int,
                    id: Long
                ) {

                    val minutes =
                        stemValues[position]

                    prefs.edit()
                        .putInt(
                            "minimum_stem_minutes",
                            minutes
                        )
                        .apply()

                    stemValueText.text =
                        "Minimum: ${stemLabels[position]} before pickup"
                }

                override fun onNothingSelected(
                    parent: AdapterView<*>?
                ) = Unit
            }


        autoBookerSwitch.setOnCheckedChangeListener {
                _,
                checked ->

            prefs.edit()
                .putBoolean(
                    "auto_booker_enabled",
                    checked
                )
                .apply()

            updateStatus(checked)
        }

        refreshSeekBar.setOnSeekBarChangeListener(
            object :
                SeekBar.OnSeekBarChangeListener {

                override fun onProgressChanged(
                    seekBar: SeekBar?,
                    progress: Int,
                    fromUser: Boolean
                ) {
                    val rate =
                        progress + 1

                    updateRefreshLabel(rate)

                    if (fromUser) {
                        prefs.edit()
                            .putInt(
                                "refresh_rate",
                                rate
                            )
                            .apply()
                    }
                }

                override fun onStartTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit

                override fun onStopTrackingTouch(
                    seekBar: SeekBar?
                ) = Unit
            }
        )

        stopButton.setOnClickListener {
            prefs.edit()
                .putBoolean(
                    "auto_booker_enabled",
                    false
                )
                .apply()

            autoBookerSwitch.isChecked =
                false

            updateStatus(false)
        }

        clearHistoryButton.setOnClickListener {
            prefs.edit()
                .putInt(
                    "success_count",
                    0
                )
                .putInt(
                    "fail_count",
                    0
                )
                .putLong(
                    "success_duration_total_ms",
                    0L
                )
                .putInt(
                    "success_duration_samples",
                    0
                )
                .putString(
                    "success_history",
                    ""
                )
                .putString(
                    "fail_history",
                    ""
                )
                .apply()

            refreshDashboard()
        }

        updateStatus(autoEnabled)
        refreshDashboard()
    }

    private fun updateRefreshLabel(
        rate: Int
    ) {
        refreshRateValue.text =
            if (rate == 1) {
                "1 tap/sec"
            } else {
                "$rate taps/sec"
            }
    }

    private fun updateStatus(
        enabled: Boolean
    ) {
        if (enabled) {
            statusText.text =
                "●  RUNNING"

            statusText.setTextColor(
                ContextCompat.getColor(
                    this,
                    R.color.ramco_green
                )
            )

            statusSubtext.text =
                "Scanning Amazon Relay for qualifying loads"

            statusCard.setBackgroundResource(
                R.drawable.bg_status_running
            )
        } else {
            statusText.text =
                "●  STOPPED"

            statusText.setTextColor(
                ContextCompat.getColor(
                    this,
                    R.color.ramco_red
                )
            )

            statusSubtext.text =
                "Auto Booker is not running"

            statusCard.setBackgroundResource(
                R.drawable.bg_status_stopped
            )
        }
    }

    private fun refreshDashboard() {
        val enabled =
            prefs.getBoolean(
                "auto_booker_enabled",
                false
            )

        if (
            autoBookerSwitch.isChecked !=
            enabled
        ) {
            autoBookerSwitch.isChecked =
                enabled
        }

        updateStatus(enabled)

        val success =
            prefs.getInt(
                "success_count",
                0
            )

        val failed =
            prefs.getInt(
                "fail_count",
                0
            )

        val totalDuration =
            prefs.getLong(
                "success_duration_total_ms",
                0L
            )

        val samples =
            prefs.getInt(
                "success_duration_samples",
                0
            )

        successCountText.text =
            success.toString()

        failCountText.text =
            failed.toString()

        avgTimeText.text =
            if (
                samples > 0 &&
                totalDuration > 0
            ) {
                val avgMs =
                    totalDuration /
                    samples

                if (avgMs < 1000L) {
                    "${avgMs}ms"
                } else {
                    String.format(
                        "%.2fs",
                        avgMs / 1000.0
                    )
                }
            } else {
                "--"
            }

        val successHistory =
            prefs.getString(
                "success_history",
                ""
            ).orEmpty()

        val failHistory =
            prefs.getString(
                "fail_history",
                ""
            ).orEmpty()

        successHistoryText.text =
            if (
                successHistory.isBlank()
            ) {
                "No successful bookings recorded yet."
            } else {
                successHistory
            }

        failHistoryText.text =
            if (
                failHistory.isBlank()
            ) {
                "No failed attempts recorded yet."
            } else {
                failHistory
            }
    }

    override fun onResume() {
        super.onResume()

        handler.removeCallbacks(
            statsRunnable
        )

        handler.post(
            statsRunnable
        )
    }

    override fun onPause() {
        handler.removeCallbacks(
            statsRunnable
        )

        super.onPause()
    }
}
