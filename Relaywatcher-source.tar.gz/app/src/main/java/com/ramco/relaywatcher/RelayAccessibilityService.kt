package com.ramco.relaywatcher

import android.accessibilityservice.AccessibilityService
import android.util.Log
import android.os.Handler
import android.os.Looper
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class RelayAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())

    private val pollRunnable = object : Runnable {
        override fun run() {
            scanCurrentScreen()
            handler.postDelayed(this, 75)
        }
    }

    // V1_1_REFRESH_FIX_4
    // Rate-limited refresh when Relay does not expose loading state.
    private val refreshRunnable = object : Runnable {
        override fun run() {
            val prefs =
                getSharedPreferences("relaywatcher", MODE_PRIVATE)

            autoBookerEnabled =
                prefs.getBoolean("auto_booker_enabled", false)

            val selectedRate =
                prefs.getInt("refresh_rate", 2).coerceIn(1, 10)

            val now = android.os.SystemClock.elapsedRealtime()

            // Respect the user's selected maximum.
            val intervalMs = 1000L / selectedRate

            if (
                autoBookerEnabled &&
                !attemptActive &&
                bookingErrorRecoveryStage == 0 &&
                boardErrorStage == 0 &&
                !wasRefreshing &&
                now - lastRefreshTapAt >= intervalMs
            ) {
                // Only send refresh actions from the Load Board.
                val root = rootInActiveWindow
                val boardVisible = root != null &&
                    findExactTextNode(root, "Load Board") != null

                val errorVisible = root != null &&
                    findExactTextNode(root, "Unable to book work opportunity") != null

                if (boardVisible && !errorVisible) {
                    val clicked = clickRefresh()

                    refreshCount++

                    if (clicked) {
                        refreshSuccessCount++
                        lastRefreshTapAt =
                            android.os.SystemClock.elapsedRealtime()
                    }
                }
            }

            if (now - refreshWindowStart >= 1000L) {
                Log.d(
                    TAG,
                    "V1.1 REFRESH FIX4: attempts=$refreshCount successfulClicks=$refreshSuccessCount selected=$selectedRate"
                )
                refreshCount = 0
                refreshSuccessCount = 0
                refreshWindowStart = now
            }

            handler.postDelayed(this, intervalMs)
        }
    }


    // -----------------------------------------------------
    // HIGH-PRIORITY BOOKING LOOP
    //
    // Once a qualifying load is clicked, stop wasting cycles
    // scanning the load board and aggressively look only for:
    //
    // Book -> Confirm and book -> Back to Load Board
    //
    // 20ms = up to 50 checks/sec.
    // Each button can still only be clicked once because the
    // existing state flags guard every action.
    // -----------------------------------------------------
    private val fastBookingRunnable = object : Runnable {
        override fun run() {

            if (!autoBookerEnabled || !attemptActive) {
                return
            }

            if (boardErrorStage != 0) {
                handler.postDelayed(this, 20L)
                return
            }

            if (bookingErrorRecoveryStage != 0) {
                handler.postDelayed(this, 20L)
                return
            }

            val root = rootInActiveWindow

            if (root != null) {
                when {
                    waitingForBook && !bookClicked -> {
                        findBookButton(root)
                    }

                    waitingForConfirm && !confirmClicked -> {
                        findConfirmAndBookButton(root)
                    }

                    waitingForLoadBoard && !loadBoardClicked -> {
                        findBackToLoadBoardButton(root)
                    }
                }
            }

            if (autoBookerEnabled && attemptActive) {
                handler.postDelayed(this, 20L)
            }
        }
    }


    companion object {
        const val TAG = "RelayWatcher"
    }

    private var lastSnapshot = ""
    private var lastHeartbeat = 0L
    private var lastStatusLog = 0L
    private var scanCount = 0
    private var scanWindowStart = android.os.SystemClock.elapsedRealtime()

    private var scanTimeTotalUs = 0L
    private var scanTimeSamples = 0
    private var scanTimeMaxUs = 0L

    private var refreshCount = 0
    private var refreshSuccessCount = 0
    private var refreshWindowStart = android.os.SystemClock.elapsedRealtime()

    // Smart refresh: never stack refresh requests faster than Relay responds.
    private var refreshWaitingForResponse = false
    private var lastRefreshTapAt = 0L

    // Adaptive refresh state
    private var adaptiveRefreshRate = 4
    private var cleanRefreshResponses = 0
    private var refreshTimeoutCount = 0

    // If Relay hasn't produced a usable response by this point,
    // back off instead of stacking refresh requests.
    private val refreshResponseTimeoutMs = 2500L
    private var lastRefreshLoopAt = 0L

    // Measure actual Relay refresh behavior, not just click actions
    private var wasRefreshing = false
    private var completedRefreshCount = 0
    private var completedRefreshWindowStart =
        android.os.SystemClock.elapsedRealtime()

    private var boardChangeCount = 0
    private var boardChangeWindowStart =
        android.os.SystemClock.elapsedRealtime()
    private var lastBoardContentSnapshot = ""
    private var testCardClicked = false
    private var waitingForBook = false
    private var bookClicked = false
    private var waitingForConfirm = false
    private var confirmClicked = false
    private var waitingForLoadBoard = false
    private var loadBoardClicked = false
    private var autoBookerEnabled = false
    private var attemptActive = false

    // Dashboard heartbeat.
    // Only queues work; networking remains on TelemetryUploader's
    // separate low-priority background thread.
    private var lastTelemetryHeartbeatAt = 0L

    // TEMPORARY ONE-SHOT TEST:
    // Only CSX -> CALUMET, exactly 16 loaded miles.
    private val oneShotTestMode = false

    private var lastAttemptKey = ""
    private var retryBlockUntil = 0L
    private var resumeSearchAt = 0L

    // Attempt tracking / history
    private var activeOrigin = ""
    private var activeDestination = ""
    private var activeMiles = 0

    private var attemptStartedAt = 0L
    private var bookClickedAt = 0L
    private var confirmClickedAt = 0L

    private val bookTimeoutMs = 5000L
    private val confirmTimeoutMs = 5000L
    private val completionTimeoutMs = 7000L

    private val allowedLanes = setOf(
        "BNSF-CICERO" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "BNSF-CICERO",

        "BNSF-CORWITH" to "BNSF-CICERO",
        "BNSF-CICERO" to "BNSF-CORWITH",

        "CSXT-BEDFORD PARK" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "CSXT-BEDFORD PARK",

        "BNSF-WILLOW SPRINGS" to "BNSF-CICERO",
        "BNSF-CICERO" to "BNSF-WILLOW SPRINGS",

        "BNSF-WILLOW SPRINGS" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "BNSF-WILLOW SPRINGS",

        "BNSF-WILLOW SPRINGS" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "BNSF-WILLOW SPRINGS",

        "NSRR-LANDERS" to "BNSF-CICERO",
        "BNSF-CICERO" to "NSRR-LANDERS",

        "NSRR-LANDERS" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "NSRR-LANDERS",

        "NSRR-LANDERS" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "NSRR-LANDERS",

        "NSRR-CHICAGO-47TH" to "BNSF-CICERO",
        "BNSF-CICERO" to "NSRR-CHICAGO-47TH",

        "NSRR-CHICAGO-47TH" to "BNSF-CORWITH",
        "BNSF-CORWITH" to "NSRR-CHICAGO-47TH",

        "NSRR-CHICAGO-47TH" to "CSXT-BEDFORD PARK",
        "CSXT-BEDFORD PARK" to "NSRR-CHICAGO-47TH"
    )

    override fun onServiceConnected() {
        super.onServiceConnected()
        Log.d(TAG, "RelayWatcher connected")
        handler.removeCallbacks(pollRunnable)
        handler.removeCallbacks(refreshRunnable)

        handler.post(pollRunnable)
        handler.post(refreshRunnable)
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        handler.removeCallbacks(fastBookingRunnable)
        handler.removeCallbacks(pollRunnable)
        handler.removeCallbacks(refreshRunnable)
        super.onDestroy()
    }

    // V1_1_REFRESH_STATE_FIX_3
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event == null) return

        when (event.eventType) {
            AccessibilityEvent.TYPE_WINDOW_CONTENT_CHANGED,
            AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED,
            AccessibilityEvent.TYPE_VIEW_SCROLLED -> {
                // An accessibility event alone is not proof that
                // Amazon finished a refresh.
                scanCurrentScreen()
            }
        }
    }

    private fun recordScanTime(startNs: Long) {
        val elapsedUs =
            (android.os.SystemClock.elapsedRealtimeNanos() - startNs) / 1000

        scanTimeTotalUs += elapsedUs
        scanTimeSamples++

        if (elapsedUs > scanTimeMaxUs) {
            scanTimeMaxUs = elapsedUs
        }

        if (scanTimeSamples >= 10) {
            val avgUs = scanTimeTotalUs / scanTimeSamples

            Log.d(
                TAG,
                "SCAN TIME: avg=${avgUs / 1000.0}ms max=${scanTimeMaxUs / 1000.0}ms samples=$scanTimeSamples"
            )

            scanTimeTotalUs = 0
            scanTimeSamples = 0
            scanTimeMaxUs = 0
        }
    }

    private var lastTextDumpAt = 0L

    private fun logVisibleRelayText() {
        val now = android.os.SystemClock.elapsedRealtime()

        // Throttle to at most 5 dumps/sec
        if (now - lastTextDumpAt < 200L) return
        lastTextDumpAt = now

        val root = rootInActiveWindow ?: return
        val texts = mutableListOf<String>()

        fun walk(node: AccessibilityNodeInfo?) {
            if (node == null) return

            node.text?.toString()?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.let { texts.add(it) }

            node.contentDescription?.toString()?.trim()
                ?.takeIf { it.isNotEmpty() }
                ?.let { texts.add(it) }

            for (i in 0 until node.childCount) {
                walk(node.getChild(i))
            }
        }

        walk(root)

        if (texts.isNotEmpty()) {
            Log.e(TAG, "UI-TEXT: " + texts.joinToString(" | "))
        }
    }


    // 0 = normal, 1 = waiting for Cancel dismissal,
    // 2 = waiting for Load Board after Back.
    private var bookingErrorRecoveryStage = 0
    private var bookingErrorRecoveryStartedAt = 0L

    private fun findExactTextNode(
        node: AccessibilityNodeInfo?,
        wanted: String
    ): AccessibilityNodeInfo? {
        if (node == null) return null

        val matches =
            node.text?.toString()?.trim()?.equals(
                wanted, ignoreCase = true
            ) == true ||
            node.contentDescription?.toString()?.trim()?.equals(
                wanted, ignoreCase = true
            ) == true

        if (matches) return node

        for (i in 0 until node.childCount) {
            val found = findExactTextNode(node.getChild(i), wanted)
            if (found != null) return found
        }

        return null
    }

    private fun clickExactText(
        root: AccessibilityNodeInfo,
        wanted: String
    ): Boolean {
        var node = findExactTextNode(root, wanted) ?: return false

        while (!node.isClickable) {
            node = node.parent ?: return false
        }

        if (!node.isEnabled) return false

        return node.performAction(
            AccessibilityNodeInfo.ACTION_CLICK
        )
    }

    private fun handleBookingErrorRecovery(
        root: AccessibilityNodeInfo,
        now: Long
    ): Boolean {

        val errorVisible = findExactTextNode(
            root, "Unable to book work opportunity"
        ) != null

        if (bookingErrorRecoveryStage == 0) {
            if (!errorVisible) return false

            bookingErrorRecoveryStage = 1
            bookingErrorRecoveryStartedAt = now
            Log.e(TAG, "BOOKING ERROR DETECTED")
        }

        if (bookingErrorRecoveryStage == 1) {
            if (errorVisible) {
                val clicked = clickExactText(root, "Cancel")
                Log.e(TAG, "ERROR CANCEL CLICK: success=$clicked")
                return true
            }

            // The Cancel popup is gone. Back is now safe.
            val backed = performGlobalAction(GLOBAL_ACTION_BACK)
            Log.e(TAG, "ERROR BACK AFTER CANCEL: success=$backed")

            if (backed) {
                bookingErrorRecoveryStage = 2
                bookingErrorRecoveryStartedAt = now
            }
            return true
        }

        if (bookingErrorRecoveryStage == 2) {
            val boardVisible =
                findExactTextNode(root, "Load Board") != null ||
                findExactTextNode(root, "Load board") != null

            if (boardVisible) {
                Log.e(TAG, "ERROR RECOVERY - LOAD BOARD VERIFIED")

                if (attemptActive) {
                    recordAttempt(
                        success = false,
                        reason = "Unable to book work opportunity",
                        finishedAt = now
                    )
                }

                attemptActive = false
                waitingForBook = false
                waitingForConfirm = false
                waitingForLoadBoard = false
                testCardClicked = false
                bookClicked = false
                confirmClicked = false
                loadBoardClicked = false
                resumeSearchAt = now + 750L
                bookingErrorRecoveryStage = 0

                Log.e(TAG, "ERROR RECOVERY COMPLETE - RESUMING")
            } else if (now - bookingErrorRecoveryStartedAt > 5000L) {
                // Remain paused rather than risk an extra Back press.
                if (now - bookingErrorRecoveryStartedAt < 5100L) {
                    Log.e(TAG, "ERROR RECOVERY WAITING FOR BOARD VERIFICATION")
                }
            }

            return true
        }

        return false
    }


    // V1_1_LOAD_BOARD_ERROR_RECOVERY
    private var boardErrorStage = 0
    private var boardErrorStartedAt = 0L
    private var boardErrorRetryAfter = 0L
    private var boardErrorLastLogAt = 0L

    private fun handleLoadBoardError(
        root: AccessibilityNodeInfo,
        now: Long
    ): Boolean {
        val errorVisible = findExactTextNode(
            root,
            "There has been an error while opening the Load Board. Please try again later or contact Customer Support."
        ) != null

        if (boardErrorStage == 0 && !errorVisible) {
            return false
        }

        if (boardErrorStage == 0) {
            boardErrorStage = 1
            boardErrorStartedAt = now
            Log.e(TAG, "V1.1 LOAD BOARD ERROR DETECTED")
        }

        if (boardErrorStage == 1) {
            if (errorVisible) {
                // Retry at controlled intervals; never spam OK.
                if (now - boardErrorStartedAt >= 1500L) {
                    val clicked = clickExactText(root, "OK")
                    Log.e(TAG, "V1.1 LOAD BOARD ERROR OK: success=$clicked")
                    boardErrorStartedAt = now
                }
                return true
            }

            boardErrorStage = 2
            boardErrorRetryAfter = now + 3000L

            Log.e(TAG, "V1.1 LOAD BOARD ERROR DISMISSED")
            return true
        }

        if (boardErrorStage == 2) {
            if (errorVisible) {
                boardErrorStage = 1
                boardErrorStartedAt = now
                return true
            }

            if (now < boardErrorRetryAfter) return true

            val boardVisible =
                findExactTextNode(root, "Load Board") != null ||
                findExactTextNode(root, "Load board") != null

            if (boardVisible) {
                boardErrorStage = 0
                refreshWaitingForResponse = false
                wasRefreshing = false

                Log.e(TAG, "V1.1 LOAD BOARD RECOVERED")
                return false
            }

            if (now - boardErrorLastLogAt >= 5000L) {
                boardErrorLastLogAt = now
                Log.w(TAG, "V1.1 WAITING FOR LOAD BOARD")
            }

            return true
        }

        return false
    }

    private fun scanCurrentScreen() {
        autoBookerEnabled =
            getSharedPreferences("relaywatcher", MODE_PRIVATE)
                .getBoolean("auto_booker_enabled", false)

        // V1_1_IDLE_CPU_FIX
        if (
            !autoBookerEnabled &&
            !attemptActive &&
            bookingErrorRecoveryStage == 0 &&
            boardErrorStage == 0
        ) {
            return
        }

        scanCount++

        val scanNow = android.os.SystemClock.elapsedRealtime()
        if (scanNow - scanWindowStart >= 1000) {
            Log.d(TAG, "SCANS/SEC: $scanCount")
            scanCount = 0
            scanWindowStart = scanNow
        }
        val startNs = android.os.SystemClock.elapsedRealtimeNanos()

        val now = android.os.SystemClock.elapsedRealtime()



        if (now - lastHeartbeat >= 1000) {
            lastHeartbeat = now
            Log.d(TAG, "SCAN-ALIVE")
        }

        /*
         * Dashboard heartbeat every 60 seconds.
         *
         * This call only adds a tiny job to TelemetryUploader's
         * separate background executor. No HTTP/network work
         * happens on this accessibility/booking thread.
         */
        if (
            autoBookerEnabled &&
            now - lastTelemetryHeartbeatAt >= 60_000L
        ) {
            lastTelemetryHeartbeatAt = now

            TelemetryUploader.sendHeartbeat(
                this
            )

            Log.d(
                TAG,
                "TELEMETRY HEARTBEAT QUEUED"
            )
        }



        val root = rootInActiveWindow
        if (root == null) {
            recordScanTime(startNs)
            return
        }

        if (handleLoadBoardError(root, now)) {
            recordScanTime(startNs)
            return
        }

        if (handleBookingErrorRecovery(root, now)) {
            recordScanTime(startNs)
            return
        }

        if (checkAttemptTimeout(now)) {
            recordScanTime(startNs)
            return
        }

        findLoadCards(root)
        findBookButton(root)
        findConfirmAndBookButton(root)
        findBackToLoadBoardButton(root)
        val texts = mutableListOf<String>()
        collectText(root, texts)

        // Relay exposes "Refreshing" while the board is loading.
        // A true -> false transition counts one completed refresh cycle.
        val isRefreshing = texts.any {
            it.equals("Refreshing", ignoreCase = true) ||
            it.contains("Refreshing", ignoreCase = true)
        }

        if (wasRefreshing && !isRefreshing) {
            completedRefreshCount++
            Log.d(TAG, "REFRESH COMPLETED")

            if (refreshWaitingForResponse) {
                refreshWaitingForResponse = false

                val responseMs =
                    android.os.SystemClock.elapsedRealtime() -
                    lastRefreshTapAt

                if (responseMs >= 750L) {
                    cleanRefreshResponses = 0
                    adaptiveRefreshRate =
                        (adaptiveRefreshRate - 1).coerceAtLeast(1)
                } else {
                    cleanRefreshResponses++
                }

                Log.d(
                    TAG,
                    "RELAY REFRESH TRANSITION: ${responseMs}ms"
                )
            }
        }

        wasRefreshing = isRefreshing

        val actualRefreshNow =
            android.os.SystemClock.elapsedRealtime()

        if (
            actualRefreshNow - completedRefreshWindowStart >= 1000L
        ) {
            Log.d(
                TAG,
                "ACTUAL REFRESHES/SEC: completed=$completedRefreshCount refreshing=$isRefreshing"
            )

            completedRefreshCount = 0
            completedRefreshWindowStart = actualRefreshNow
        }

        val rails = texts
            .filter { isRailLocation(it) }
            .map { normalizeRail(it) }

        val distanceRegex =
            Regex("""^\s*(\d+)\s*miles?\s*$""", RegexOption.IGNORE_CASE)

        val miles = texts.mapNotNull { text ->
            distanceRegex.matchEntire(text)
                ?.groupValues
                ?.get(1)
                ?.toIntOrNull()
        }


        val statusNow = android.os.SystemClock.elapsedRealtime()
        if (statusNow - lastStatusLog >= 1000) {
            lastStatusLog = statusNow
            Log.d(TAG, "STATUS: rails=${rails.size} miles=${miles.size}")

        if (rails.size % 2 != 0) {
            Log.d(TAG, "ODD-RAILS: ${rails.joinToString(" || ")}")

            for (t in texts) {
                if (
                    t.contains(", IL", ignoreCase = true) ||
                    t.contains("CHICAGO", ignoreCase = true) ||
                    t.contains("BEDFORD", ignoreCase = true) ||
                    t.contains("CICERO", ignoreCase = true) ||
                    t.contains("CORWITH", ignoreCase = true) ||
                    t.contains("LANDERS", ignoreCase = true)
                ) {
                    Log.d(TAG, "LOCATION-TEXT: $t")
                }
            }
        }
        }

        val snapshot = rails.joinToString("|") + "::" + miles.joinToString(",")

        if (
            lastBoardContentSnapshot.isNotEmpty() &&
            snapshot != lastBoardContentSnapshot
        ) {
            boardChangeCount++
        }

        lastBoardContentSnapshot = snapshot

        val boardChangeNow =
            android.os.SystemClock.elapsedRealtime()

        if (
            boardChangeNow - boardChangeWindowStart >= 1000L
        ) {
            Log.d(
                TAG,
                "BOARD CHANGES/SEC: $boardChangeCount"
            )

            boardChangeCount = 0
            boardChangeWindowStart = boardChangeNow
        }

        if (snapshot == lastSnapshot) {
            recordScanTime(startNs)
            return
        }
        lastSnapshot = snapshot


        val loadCount = minOf(rails.size / 2, miles.size)

        for (i in 0 until loadCount) {
            val origin = rails[i * 2]
            val destination = rails[i * 2 + 1]
            val loadedMiles = miles[i]

            val laneAllowed = allowedLanes.contains(origin to destination)
            val milesAllowed = loadedMiles <= 12
            val finalMatch = laneAllowed && milesAllowed

            val endNs = android.os.SystemClock.elapsedRealtimeNanos()
            val processingUs = (endNs - startNs) / 1000

            Log.d(
                TAG,
                "SPEED: ${processingUs}us | $origin -> $destination | ${loadedMiles}mi"
            )


            Log.d(
                TAG,
                "TEST: $origin -> $destination | ${loadedMiles}mi | " +
                    "LANE=${if (laneAllowed) "YES" else "NO"} | " +
                    "DIST=${if (milesAllowed) "YES" else "NO"}"
            )

            if (finalMatch) {
                Log.e(
                    TAG,
                    "!!! MATCH DETECTED !!! $origin -> $destination | ${loadedMiles}mi"
                )
            }
        }

        recordScanTime(startNs)
    }


    private fun clickRefresh(): Boolean {
        val root = rootInActiveWindow ?: return false

        fun search(node: AccessibilityNodeInfo?): Boolean {
            if (node == null) return false

            val text = node.text?.toString() ?: ""
            val desc = node.contentDescription?.toString() ?: ""

            val isRefresh =
                text.equals("Refresh", ignoreCase = true) ||
                desc.contains("Refresh", ignoreCase = true)

            if (isRefresh) {
                if (node.isClickable) {
                    if (node.performAction(
                            AccessibilityNodeInfo.ACTION_CLICK
                        )
                    ) return true
                }

                val parent = node.parent

                if (parent != null) {
                    if (parent.isClickable) {
                        if (parent.performAction(
                                AccessibilityNodeInfo.ACTION_CLICK
                            )
                        ) return true
                    }

                    for (i in 0 until parent.childCount) {
                        val sibling = parent.getChild(i) ?: continue

                        if (sibling.isClickable) {
                            if (sibling.performAction(
                                    AccessibilityNodeInfo.ACTION_CLICK
                                )
                            ) return true
                        }
                    }
                }
            }

            for (i in 0 until node.childCount) {
                if (search(node.getChild(i))) return true
            }

            return false
        }

        return search(root)
    }



    private fun getStemMinutes(
        texts: List<String>
    ): Long? {

        /*
         * Relay format observed:
         * Mon, Oct 26, 22:48 CDT
         *
         * First matching timestamp inside the load card
         * is the FIRST PICKUP time.
         */
        val dateRegex =
            Regex(
                """^(Mon|Tue|Wed|Thu|Fri|Sat|Sun),\s+[A-Za-z]{3}\s+\d{1,2},\s+\d{2}:\d{2}\s+[A-Z]{3}$"""
            )

        val pickupText =
            texts.firstOrNull {
                dateRegex.matches(it.trim())
            }?.trim()
                ?: return null

        return try {

            val now =
                System.currentTimeMillis()

            val nowCal =
                java.util.Calendar.getInstance()

            var year =
                nowCal.get(
                    java.util.Calendar.YEAR
                )

            fun parse(y: Int): java.util.Date? {

                val formatter =
                    java.text.SimpleDateFormat(
                        "EEE, MMM d, HH:mm z yyyy",
                        java.util.Locale.US
                    )

                formatter.isLenient = false

                return formatter.parse(
                    "$pickupText $y"
                )
            }

            var pickup =
                parse(year)
                    ?: return null

            /*
             * Handle Dec -> Jan year rollover.
             */
            if (
                nowCal.get(
                    java.util.Calendar.MONTH
                ) == java.util.Calendar.DECEMBER
            ) {

                val pickupCal =
                    java.util.Calendar.getInstance().apply {
                        time = pickup
                    }

                if (
                    pickupCal.get(
                        java.util.Calendar.MONTH
                    ) == java.util.Calendar.JANUARY
                ) {
                    year += 1

                    pickup =
                        parse(year)
                            ?: return null
                }
            }

            (pickup.time - now) / 60000L

        } catch (t: Throwable) {

            Log.w(
                TAG,
                "STEM PARSE FAILED: $pickupText"
            )

            null
        }
    }


    private fun findLoadCards(node: AccessibilityNodeInfo?): Boolean {
        if (node == null) return false

        // Search smaller child subtrees FIRST.
        // This prevents the entire Relay screen from being mistaken for one load card.
        for (i in 0 until node.childCount) {
            if (findLoadCards(node.getChild(i))) {
                return true
            }
        }

        val allTexts = mutableListOf<String>()
        collectText(node, allTexts)

        val distanceRegex =
            Regex("""^\s*(\d+)\s*miles?\s*$""", RegexOption.IGNORE_CASE)

        val distances = allTexts.filter {
            distanceRegex.matches(it)
        }

        val locations = allTexts.filter {
            val t = it.uppercase()

            !t.contains("UIIA") && (
                t.contains("BNSF") ||
                t.contains("CSXT") ||
                t.contains("CSX") ||
                t.contains("NSRR") ||
                t.contains("NSSR") ||
                t.contains("CALUMET") ||
                t.contains("UPRR")
            )
        }

        if (distances.size == 1 && locations.size == 2) {
            val origin = normalizeRail(locations[0])
            val destination = normalizeRail(locations[1])

            val miles = Regex("\\d+")
                .find(distances[0])
                ?.value
                ?.toIntOrNull()
                ?: return false

            val laneAllowed =
                allowedLanes.contains(origin to destination)

            /*
             * Minimum stem-time preference.
             *
             * Example:
             * selected 90 minutes
             * pickup is 70 minutes away
             * => SKIP
             */
            val minimumStemMinutes =
                getSharedPreferences(
                    "relaywatcher",
                    MODE_PRIVATE
                ).getInt(
                    "minimum_stem_minutes",
                    90
                )

            val stemMinutes =
                getStemMinutes(allTexts)

            /*
             * Fail closed:
             * If Relay's pickup timestamp cannot be read,
             * do NOT risk booking a short-stem load.
             */
            val stemAllowed =
                stemMinutes != null &&
                stemMinutes >= minimumStemMinutes

            val rawOrigin =
                locations[0].uppercase()

            val rawDestination =
                locations[1].uppercase()

            val oneShotConsumed =
                getSharedPreferences("relaywatcher", MODE_PRIVATE)
                    .getBoolean("one_shot_test_consumed_v2", false)

            val oneShotTestMatch =
                (
                    rawOrigin.contains("CSX") &&
                    rawDestination.contains("CALUMET") &&
                    miles == 16
                )

            // During this temporary test build, NORMAL lanes are disabled.
            // Only the exact one-shot test load can be clicked.
            val eligibleForBooking =
                if (oneShotTestMode) {
                    oneShotTestMatch && !oneShotConsumed
                } else {
                    laneAllowed &&
                    miles <= 12 &&
                    stemAllowed
                }

            if (oneShotTestMatch) {
                Log.e(
                    TAG,
                    "ONE-SHOT TEST MATCH: $rawOrigin -> $rawDestination | ${miles}mi | consumed=$oneShotConsumed"
                )
            }

            // TEMP TEST: prove the fast per-card match path works.
            val bounds = android.graphics.Rect()
            node.getBoundsInScreen(bounds)

            var clickableNode: AccessibilityNodeInfo? = node
            var levelsUp = 0

            while (clickableNode != null &&
                   !clickableNode.isClickable &&
                   levelsUp < 6) {
                clickableNode = clickableNode.parent
                levelsUp++
            }

            val clickBounds = android.graphics.Rect()
            clickableNode?.getBoundsInScreen(clickBounds)

            Log.e(
                TAG,
                "!!! TEST MATCH !!! $origin -> $destination | ${miles}mi | STEM=${stemMinutes ?: -1}m MIN=${minimumStemMinutes}m STEM_OK=$stemAllowed | REAL=${laneAllowed && miles <= 12 && stemAllowed} | CARD=$bounds | CLICKABLE=${clickableNode?.isClickable} | UP=$levelsUp | CLICK_BOUNDS=$clickBounds"
            )

            val attemptKey =
                "$origin|$destination|$miles|" +
                "${bounds.left},${bounds.top},${bounds.right},${bounds.bottom}"

            val now = android.os.SystemClock.elapsedRealtime()

            if (loadBoardClicked && now >= resumeSearchAt) {
                loadBoardClicked = false
            }

            val recentlyAttemptedSameCard =
                attemptKey == lastAttemptKey &&
                now < retryBlockUntil

            if (
                autoBookerEnabled &&
                eligibleForBooking &&
                !attemptActive &&
                !recentlyAttemptedSameCard &&
                !testCardClicked &&
                clickableNode?.isClickable == true
            ) {
                val clicked = clickableNode!!.performAction(
                    AccessibilityNodeInfo.ACTION_CLICK
                )

                Log.e(
                    TAG,
                    "REAL CARD CLICK: success=$clicked | $origin -> $destination | ${miles}mi"
                )

                if (clicked) {

                    // Consume the one-shot BEFORE continuing.
                    // Even if RelayWatcher/service restarts, no second
                    // load can be selected by this test build.
                    if (oneShotTestMode) {
                        getSharedPreferences(
                            "relaywatcher",
                            MODE_PRIVATE
                        ).edit()
                            .putBoolean(
                                "one_shot_test_consumed_v2",
                                true
                            )
                            .apply()

                        Log.e(
                            TAG,
                            "ONE-SHOT TEST CONSUMED - NO MORE LOADS WILL BE SELECTED"
                        )
                    }

                    testCardClicked = true
                    attemptActive = true
                    lastAttemptKey = attemptKey

                    // Don't immediately hit this exact same card again
                    // after returning to the board.
                    retryBlockUntil =
                        android.os.SystemClock.elapsedRealtime() + 5000L

                    activeOrigin = origin
                    activeDestination = destination
                    activeMiles = miles

                    attemptStartedAt =
                        android.os.SystemClock.elapsedRealtime()

                    bookClickedAt = 0L
                    confirmClickedAt = 0L

                    waitingForBook = true


                    // Immediately enter high-priority booking mode.
                    handler.removeCallbacks(fastBookingRunnable)
                    handler.post(fastBookingRunnable)

                    // First qualifying load clicked.
                    // Stop scanning all remaining load cards immediately.
                    return true
                }
            }

            if (
                laneAllowed &&
                miles <= 12 &&
                stemAllowed
            ) {
                Log.e(
                    TAG,
                    "!!! MATCH DETECTED !!! $origin -> $destination | ${miles}mi"
                )
            }

            // This subtree is already one complete load card.
            // Do not descend farther and detect the same card again.
            return false
        }

        return false
    }


    private fun findBookButton(node: AccessibilityNodeInfo?): Boolean {
    if (node == null) return false
    if (!autoBookerEnabled || !attemptActive || !waitingForBook || bookClicked) {
        return false
    }

    val text = node.text?.toString()?.trim().orEmpty()

    if (text.equals("Book", ignoreCase = true)) {
        Log.e(TAG, "BOOK BUTTON FOUND")

        var target: AccessibilityNodeInfo? = node
        var hops = 0

        while (target != null && !target.isClickable && hops < 6) {
            target = target.parent
            hops++
        }

        if (
            target != null &&
            target.isClickable &&
            autoBookerEnabled &&
            attemptActive &&
            waitingForBook &&
            !bookClicked
        ) {
            val clicked =
                target.performAction(AccessibilityNodeInfo.ACTION_CLICK)

            Log.e(TAG, "BOOK CLICK: success=$clicked")

            if (clicked) {
                bookClicked = true
                waitingForBook = false
                waitingForConfirm = true
                bookClickedAt = android.os.SystemClock.elapsedRealtime()

                // STOP searching immediately.
                return true
            }
        }
    }

    // Search children, but stop the entire traversal on the
    // first successful Book click.
    for (i in 0 until node.childCount) {
        val child = node.getChild(i)

        if (findBookButton(child)) {
            return true
        }
    }

    return false
}


    private fun findConfirmAndBookButton(node: AccessibilityNodeInfo?): Boolean {
    if (node == null) return false
    if (
        !autoBookerEnabled ||
        !attemptActive ||
        !waitingForConfirm ||
        confirmClicked
    ) {
        return false
    }

    val text = node.text?.toString()?.trim().orEmpty()

    if (text.equals("Confirm and book", ignoreCase = true)) {
        Log.e(TAG, "CONFIRM BUTTON FOUND")

        var target: AccessibilityNodeInfo? = node
        var hops = 0

        while (target != null && !target.isClickable && hops < 6) {
            target = target.parent
            hops++
        }

        if (
            target != null &&
            target.isClickable &&
            autoBookerEnabled &&
            attemptActive &&
            waitingForConfirm &&
            !confirmClicked
        ) {
            val clicked =
                target.performAction(AccessibilityNodeInfo.ACTION_CLICK)

            Log.e(TAG, "CONFIRM CLICK: success=$clicked")

            if (clicked) {
                confirmClicked = true
                waitingForConfirm = false
                waitingForLoadBoard = true
                confirmClickedAt = android.os.SystemClock.elapsedRealtime()

                // STOP searching immediately.
                return true
            }
        }
    }

    for (i in 0 until node.childCount) {
        val child = node.getChild(i)

        if (findConfirmAndBookButton(child)) {
            return true
        }
    }

    return false
}


    private fun findBackToLoadBoardButton(
        node: AccessibilityNodeInfo?
    ) {
        if (node == null) return

        val text =
            node.text?.toString()?.trim() ?: ""

        val desc =
            node.contentDescription?.toString()?.trim() ?: ""

        val isBackToLoadBoard =
            text.equals(
                "Back to Load Board",
                ignoreCase = true
            ) ||
            desc.equals(
                "Back to Load Board",
                ignoreCase = true
            )

        if (isBackToLoadBoard) {

            Log.e(
                TAG,
                "BACK TO LOAD BOARD FOUND"
            )

            if (
                attemptActive &&
                !loadBoardClicked
            ) {

                /*
                 * First try normal Accessibility click.
                 * Climb farther than before because Relay's
                 * Compose hierarchy may wrap the text deeply.
                 */
                var clickableNode:
                    AccessibilityNodeInfo? = node

                var levelsUp = 0

                while (
                    clickableNode != null &&
                    !clickableNode.isClickable &&
                    levelsUp < 15
                ) {
                    clickableNode =
                        clickableNode.parent

                    levelsUp++
                }

                var clicked = false

                if (
                    clickableNode?.isClickable == true
                ) {
                    clicked =
                        clickableNode.performAction(
                            AccessibilityNodeInfo.ACTION_CLICK
                        )

                    Log.e(
                        TAG,
                        "BACK TO LOAD BOARD ACCESSIBILITY CLICK: success=$clicked levels=$levelsUp"
                    )
                }

                /*
                 * Fallback:
                 * Tap the center of the visible text node.
                 *
                 * This runs ONLY on the failure/completion
                 * screen, never during normal card scanning.
                 */
                if (!clicked) {

                    val bounds =
                        android.graphics.Rect()

                    node.getBoundsInScreen(bounds)

                    val x =
                        bounds.centerX().toFloat()

                    val y =
                        bounds.centerY().toFloat()

                    val path =
                        android.graphics.Path().apply {
                            moveTo(x, y)
                        }

                    val gesture =
                        android.accessibilityservice.GestureDescription.Builder()
                            .addStroke(
                                android.accessibilityservice.GestureDescription.StrokeDescription(
                                    path,
                                    0L,
                                    60L
                                )
                            )
                            .build()

                    clicked =
                        dispatchGesture(
                            gesture,
                            null,
                            null
                        )

                    Log.e(
                        TAG,
                        "BACK TO LOAD BOARD GESTURE: success=$clicked x=$x y=$y"
                    )
                }

                if (clicked) {

                    loadBoardClicked = true
                    waitingForLoadBoard = false

                    val finishedAt =
                        android.os.SystemClock.elapsedRealtime()

                    if (confirmClicked) {

                        recordAttempt(
                            success = true,
                            reason = "Booked",
                            finishedAt = finishedAt
                        )

                    } else {

                        recordAttempt(
                            success = false,
                            reason = "Load unavailable / failed before confirm",
                            finishedAt = finishedAt
                        )
                    }

                    attemptActive = false

                    waitingForBook = false
                    waitingForConfirm = false
                    waitingForLoadBoard = false

                    testCardClicked = false
                    bookClicked = false
                    confirmClicked = false

                    resumeSearchAt =
                        android.os.SystemClock.elapsedRealtime() +
                        750L

                    Log.e(
                        TAG,
                        "ATTEMPT FINISHED - RESUMING LOAD BOARD"
                    )
                }
            }
        }

        for (i in 0 until node.childCount) {
            findBackToLoadBoardButton(
                node.getChild(i)
            )
        }
    }

    private fun checkAttemptTimeout(now: Long): Boolean {
        if (!attemptActive) return false

        var timedOut = false
        var reason = ""

        if (
            waitingForBook &&
            attemptStartedAt > 0L &&
            now - attemptStartedAt >= bookTimeoutMs
        ) {
            timedOut = true
            reason = "Timeout waiting for Book"
        } else if (
            waitingForConfirm &&
            bookClickedAt > 0L &&
            now - bookClickedAt >= confirmTimeoutMs
        ) {
            timedOut = true
            reason = "Timeout waiting for Confirm"
        } else if (
            waitingForLoadBoard &&
            confirmClickedAt > 0L &&
            now - confirmClickedAt >= completionTimeoutMs
        ) {
            timedOut = true
            reason = "Confirm sent - completion not verified"
        }

        if (!timedOut) return false

        Log.e(TAG, "ATTEMPT TIMEOUT: $reason")

        recordAttempt(
            success = false,
            reason = reason,
            finishedAt = now
        )

        // Try to return toward the load board.
        performGlobalAction(GLOBAL_ACTION_BACK)

        attemptActive = false
        waitingForBook = false
        waitingForConfirm = false
        waitingForLoadBoard = false

        testCardClicked = false
        bookClicked = false
        confirmClicked = false
        loadBoardClicked = false

        resumeSearchAt = now + 750L

        Log.e(TAG, "TIMEOUT RECOVERY - RESUMING")
        return true
    }


    private fun recordAttempt(
        success: Boolean,
        reason: String,
        finishedAt: Long
    ) {
        if (attemptStartedAt <= 0L) return

        val prefs =
            getSharedPreferences("relaywatcher", MODE_PRIVATE)

        ensureDailyStats(prefs)

        val bookingDurationMs =
            if (
                success &&
                confirmClickedAt > attemptStartedAt
            ) {
                confirmClickedAt - attemptStartedAt
            } else {
                finishedAt - attemptStartedAt
            }

        val timestamp =
            java.text.SimpleDateFormat(
                "MM-dd HH:mm:ss",
                java.util.Locale.US
            ).format(java.util.Date())

        val durationSeconds =
            String.format(
                java.util.Locale.US,
                "%.3f",
                bookingDurationMs / 1000.0
            )

        val line =
            "$timestamp | $activeOrigin -> $activeDestination | " +
            "${activeMiles}mi | ${durationSeconds}s | $reason"

        val key =
            if (success) "success_history"
            else "fail_history"

        val oldHistory =
            prefs.getString(key, "") ?: ""

        val newHistory =
            if (oldHistory.isBlank()) {
                line
            } else {
                "$line\n$oldHistory"
            }
            .lineSequence()
            .take(100)
            .joinToString("\n")

        val edit = prefs.edit()

        if (success) {
            val successes =
                prefs.getInt("success_count", 0) + 1

            val totalDuration =
                prefs.getLong(
                    "success_duration_total_ms",
                    0L
                ) + bookingDurationMs

            val durationSamples =
                prefs.getInt(
                    "success_duration_samples",
                    0
                ) + 1

            edit
                .putInt("success_count", successes)
                .putLong(
                    "success_duration_total_ms",
                    totalDuration
                )
                .putInt(
                    "success_duration_samples",
                    durationSamples
                )
        } else {
            val failures =
                prefs.getInt("fail_count", 0) + 1

            edit.putInt("fail_count", failures)
        }

        edit
            .putString(key, newHistory)
            .apply()

        Log.e(
            TAG,
            "HISTORY: ${if (success) "SUCCESS" else "FAIL"} | $line"
        )

        /*
         * TELEMETRY:
         *
         * This only queues a tiny background task.
         * No network work happens on the accessibility
         * or fast-booking thread.
         */
        val cardToBookMs =
            if (
                bookClickedAt > 0L &&
                attemptStartedAt > 0L &&
                bookClickedAt >= attemptStartedAt
            ) {
                bookClickedAt - attemptStartedAt
            } else {
                null
            }

        val bookToConfirmMs =
            if (
                confirmClickedAt > 0L &&
                bookClickedAt > 0L &&
                confirmClickedAt >= bookClickedAt
            ) {
                confirmClickedAt - bookClickedAt
            } else {
                null
            }

        TelemetryUploader.sendAttempt(
            context = this,
            success = success,
            reason = reason,
            origin = activeOrigin,
            destination = activeDestination,
            miles = activeMiles,
            cardToBookMs = cardToBookMs,
            bookToConfirmMs = bookToConfirmMs,
            totalMs = bookingDurationMs
        )
    }


    private fun ensureDailyStats(
        prefs: android.content.SharedPreferences
    ) {
        val today =
            java.text.SimpleDateFormat(
                "yyyy-MM-dd",
                java.util.Locale.US
            ).format(java.util.Date())

        val savedDate =
            prefs.getString("stats_date", "") ?: ""

        if (savedDate != today) {
            prefs.edit()
                .putString("stats_date", today)
                .putInt("success_count", 0)
                .putInt("fail_count", 0)
                .putLong("success_duration_total_ms", 0L)
                .putInt("success_duration_samples", 0)
                .apply()
        }
    }


    private fun collectText(
        node: AccessibilityNodeInfo?,
        output: MutableList<String>
    ) {
        if (node == null) return

        val text = node.text?.toString()?.trim()

        if (!text.isNullOrBlank()) {
            output.add(text)
        }

        for (i in 0 until node.childCount) {
            collectText(node.getChild(i), output)
        }
    }

    private fun isRailLocation(text: String): Boolean {
        val t = text.uppercase()

        if (t.contains("UIIA")) return false

        return (
            t.contains("BNSF") && (
                t.contains("CICERO") ||
                t.contains("CORWITH") ||
                t.contains("WILLOW")
            )
        ) || (
            t.contains("CSXT") &&
            t.contains("BEDFORD")
        ) || (
            t.contains("NSRR") && (
                t.contains("LANDERS") ||
                t.contains("47TH") ||
                t.contains("63RD") ||
                t.contains("CALUMET")
            )
        ) || (
            t.contains("UPRR") && (
                t.contains("DOLTON") ||
                t.contains("GLOBAL")
            )
        ) || t.contains("IGQ1")
    }

    private fun normalizeRail(raw: String): String {
        var t = raw.uppercase()

        t = t
            .replace("-CS", "")
            .replace("-TOT", "")
            .replace("-EFC", "")

        return when {
            t.contains("BNSF") && t.contains("CICERO") ->
                "BNSF-CICERO"

            t.contains("BNSF") && t.contains("CORWITH") ->
                "BNSF-CORWITH"

            t.contains("BNSF") && t.contains("WILLOW") ->
                "BNSF-WILLOW SPRINGS"

            t.contains("CSXT") && t.contains("BEDFORD") ->
                "CSXT-BEDFORD PARK"

            t.contains("NSRR") && t.contains("LANDERS") ->
                "NSRR-LANDERS"

            t.contains("NSRR") && t.contains("47TH") ->
                "NSRR-CHICAGO-47TH"

            t.contains("IGQ1") ->
                "IGQ1-HARVEY"

            else -> t.trim()
        }
    }
}
